# Mindustryalization
A mod about making everything for speed and efficiency

## Importing

Simply download this repository as a zip, then import it through the `Mods` dialog in Mindustry. You can unzip this repo inside Mindustry's `mods/` folder. Or, you can use the import github mod dialogue and type "vortetty/Mindustryalization" in the box.
